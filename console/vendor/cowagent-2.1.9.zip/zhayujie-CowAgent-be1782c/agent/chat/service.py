"""
ChatService - Wraps the Agent stream execution to produce CHAT protocol chunks.

Translates agent events (message_update, message_end, tool_execution_end, etc.)
into the CHAT socket protocol format (content chunks with segment_id, tool_calls chunks).
"""

import time
from typing import Callable, Optional

from common.log import logger


class ChatService:
    """
    High-level service that runs an Agent for a given query and streams
    the results as CHAT protocol chunks via a callback.

    Usage:
        svc = ChatService(agent_bridge)
        svc.run(query, session_id, send_chunk_fn)
    """

    def __init__(self, agent_bridge):
        """
        :param agent_bridge: AgentBridge instance (manages agent lifecycle)
        """
        self.agent_bridge = agent_bridge

    def run(
        self,
        query: str,
        session_id: str,
        send_chunk_fn: Callable[[dict], None],
        channel_type: str = "",
        agent_id: str = None,
        request_id: str = None,  # noqa: RUF013
    ):
        """
        Run the agent for *query* and stream results back via *send_chunk_fn*.

        The method blocks until the agent finishes. After it returns the SDK
        will automatically send the final (streaming=false) message.

        :param query: user query text
        :param session_id: session identifier for agent isolation
        :param send_chunk_fn: callable(chunk_data: dict) to send a streaming chunk
        :param channel_type: source channel (e.g. "web", "feishu") for persistence
        :param agent_id: selected agent profile; defaults to the configured default
        :param request_id: per-request cancellation key; defaults to session scope
        """
        resolved_agent_id = self.agent_bridge._resolve_agent_id(agent_id)
        agent = self.agent_bridge.get_agent(
            session_id=session_id, agent_id=resolved_agent_id
        )
        if agent is None:
            raise RuntimeError("Failed to initialise agent for the session")

        # Pass context metadata to model for downstream API requests
        if hasattr(agent, 'model'):
            agent.model.channel_type = channel_type or ""
            agent.model.session_id = session_id or ""
            agent.model.agent_id = resolved_agent_id

        # Build a context so context-aware tools (e.g. scheduler) can resolve the
        # receiver/session. This streaming path bypasses agent_bridge.agent_reply,
        # so the attach step that normally happens there must be done here too.
        context = self._build_context(
            query, session_id, channel_type, resolved_agent_id
        )
        self._attach_context_aware_tools(agent, context)

        # Mark this session as mid-run so the self-evolution idle scan does not
        # fire concurrently when a single turn runs longer than idle_minutes.
        self._mark_run_active(agent, True)

        # State shared between the event callback and this method
        state = _StreamState()

        def flush_file_links():
            """Emit any buffered file links as content, then drop them."""
            if not state.pending_file_links:
                return
            links = state.pending_file_links
            state.pending_file_links = []
            send_chunk_fn({
                "chunk_type": "content",
                "delta": "\n\n" + "\n\n".join(links) + "\n\n",
                "segment_id": state.segment_id,
            })

        def on_event(event: dict):
            """Translate agent events into CHAT protocol chunks."""
            event_type = event.get("type")
            data = event.get("data", {})

            if event_type == "reasoning_update":
                delta = data.get("delta", "")
                if delta:
                    send_chunk_fn({
                        "chunk_type": "reasoning",
                        "delta": delta,
                        "segment_id": state.segment_id,
                    })

            elif event_type == "message_update":
                # Incremental text delta
                delta = data.get("delta", "")
                if delta:
                    send_chunk_fn({
                        "chunk_type": "content",
                        "delta": delta,
                        "segment_id": state.segment_id,
                    })

            elif event_type == "message_end":
                # A content segment finished.
                tool_calls = data.get("tool_calls", [])
                if tool_calls:
                    # After tool_calls are executed the next content will be
                    # a new segment; collect tool results until turn_end.
                    state.pending_tool_results = []

            elif event_type == "tool_retrieval":
                # Forward sanitized retrieval metadata for progress displays.
                send_chunk_fn({
                    "chunk_type": "tool_retrieval",
                    "data": data,
                })

            elif event_type == "file_to_send":
                url = data.get("url") or ""
                if url:
                    fname = data.get("file_name") or "file"
                    ft = data.get("file_type") or "file"
                    if ft == "image":
                        link = f"![{fname}]({url})"
                    else:
                        link = f"[{fname}]({url})"
                    state.pending_file_links.append(link)
                    # Remove url so the model won't repeat it in its reply
                    data.pop("url", None)

            elif event_type == "tool_execution_start":
                # Notify the client that a tool is about to run (with its input args)
                tool_name = data.get("tool_name", "")
                arguments = data.get("arguments", {})
                # Cache arguments keyed by tool_call_id so tool_execution_end can include them
                tool_call_id = data.get("tool_call_id", tool_name)
                state.pending_tool_arguments[tool_call_id] = arguments
                send_chunk_fn({
                    "chunk_type": "tool_start",
                    "tool": tool_name,
                    "arguments": arguments,
                    # Carry the call id so later subagent_step chunks can attach
                    # their inner steps to the right card via card_id.
                    "tool_id": tool_call_id,
                })

            elif event_type == "tool_execution_end":
                tool_name = data.get("tool_name", "")
                tool_call_id = data.get("tool_call_id", tool_name)
                # Retrieve cached arguments from the matching tool_execution_start event
                arguments = state.pending_tool_arguments.pop(tool_call_id, data.get("arguments", {}))
                result = data.get("result", "")
                status = data.get("status", "unknown")
                execution_time = data.get("execution_time", 0)
                elapsed_str = f"{execution_time:.2f}s"

                # Serialise result to string if needed
                if not isinstance(result, str):
                    import json
                    try:
                        result = json.dumps(result, ensure_ascii=False)
                    except Exception:
                        result = str(result)

                tool_info = {
                    "name": tool_name,
                    "arguments": arguments,
                    "result": result,
                    "status": status,
                    "elapsed": elapsed_str,
                    # Same id the matching tool_start carried, so the frontend can
                    # carry sub agent substeps over from the loading card to this
                    # resolved one (see collectLoadingSubsteps / carried.get).
                    "id": tool_call_id,
                }

                if state.pending_tool_results is not None:
                    state.pending_tool_results.append(tool_info)

            elif event_type == "subagent_step":
                # A single step a sub agent ran inside a still-in-flight
                # `subagent` tool call. Forwarded immediately (NOT batched into
                # pending_tool_results) so the console can follow the sub
                # agent's progress live instead of waiting minutes for the whole
                # spawn to finish and flush at turn_end.
                send_chunk_fn({
                    "chunk_type": "subagent_step",
                    "card_id": data.get("card_id"),
                    "step_id": data.get("step_id"),
                    "phase": data.get("phase"),
                    # Frontend expects `tool`; the event carries `tool_name`.
                    "tool": data.get("tool_name") or data.get("tool") or "tool",
                    "arguments": data.get("arguments") or {},
                    "status": data.get("status"),
                    "execution_time": data.get("execution_time"),
                    "error": data.get("error"),
                })

            elif event_type == "artifact":
                # A file a (sub) agent wrote. Forward live so it can be previewed
                # as soon as it exists rather than only after the turn settles.
                send_chunk_fn({
                    "chunk_type": "artifact",
                    "artifact": data,
                })

            elif event_type == "turn_end":
                has_tool_calls = data.get("has_tool_calls", False)
                if has_tool_calls and state.pending_tool_results:
                    # Flush collected tool results as a single tool_calls chunk
                    send_chunk_fn({
                        "chunk_type": "tool_calls",
                        "tool_calls": state.pending_tool_results,
                    })
                    state.pending_tool_results = None
                    # Next content belongs to a new segment
                    state.segment_id += 1
                # Now that the tool results are out, the links belong to the
                # content that follows them.
                flush_file_links()

        # Run the agent with our event callback ---------------------------
        logger.info(
            f"[ChatService] Starting agent run: agent={resolved_agent_id}, "
            f"session={session_id}, query={query[:80]}"
        )

        from config import conf
        max_context_turns = conf().get("agent_max_context_turns", 20)

        # Get full system prompt with skills
        full_system_prompt = agent.get_full_system_prompt()

        # Create a copy of messages for this execution
        with agent.messages_lock:
            messages_copy = agent.messages.copy()
            original_length = len(agent.messages)

        from agent.protocol.agent_stream import AgentStreamExecutor

        # Register a cancel token so /cancel can abort this in-flight run.
        # API calls can key by request; IM channels remain session scoped.
        from agent.protocol import get_cancel_registry, get_steer_registry
        registry = get_cancel_registry()
        steer_registry = get_steer_registry()
        scoped_session_key = (
            self.agent_bridge._cancel_key(
                resolved_agent_id,
                session_id,
                self.agent_bridge.agent_registry.default_agent_id,
            )
            if session_id
            else None
        )
        cancel_key = (
            self.agent_bridge._cancel_key(
                resolved_agent_id,
                request_id,
                self.agent_bridge.agent_registry.default_agent_id,
            )
            if request_id
            else scoped_session_key
        )
        # Both the token and its session grouping are namespaced: two Agents
        # serving the same session id must not cancel or steer each other.
        cancel_event = (
            registry.register(cancel_key, session_id=scoped_session_key)
            if cancel_key
            else None
        )
        steer_inbox = (
            steer_registry.register(scoped_session_key) if scoped_session_key else None
        )

        executor = AgentStreamExecutor(
            agent=agent,
            model=agent.model,
            system_prompt=full_system_prompt,
            tools=agent.tools,
            max_turns=agent.max_steps,
            on_event=on_event,
            messages=messages_copy,
            max_context_turns=max_context_turns,
            cancel_event=cancel_event,
            steer_inbox=steer_inbox,
        )

        try:
            if cancel_event is not None and cancel_event.is_set():
                logger.info(
                    f"[ChatService] Skipping pre-cancelled run: agent={resolved_agent_id}, "
                    f"session={session_id}"
                )
                return
            response = executor.run_stream(query)
        except Exception:
            # If executor cleared messages (context overflow), sync back
            if len(executor.messages) == 0:
                with agent.messages_lock:
                    agent.messages.clear()
                    logger.info("[ChatService] Cleared agent message history after executor recovery")
            raise
        finally:
            # Clear the mid-run flag so idle scans can review this session again.
            self._mark_run_active(agent, False)
            # Release cancel token to keep the registry bounded.
            if cancel_key:
                try:
                    registry.unregister(cancel_key)
                except Exception:
                    pass
            if scoped_session_key and steer_inbox is not None:
                steer_registry.unregister(scoped_session_key, steer_inbox)

        # A run that ends without a closing turn_end (e.g. the last turn had no
        # tool calls to flush) must still deliver whatever the send tool uploaded.
        flush_file_links()

        # Sync executor messages back to agent (thread-safe).
        # The executor may have trimmed context, making its list shorter than
        # original_length. In that case we must replace entirely — just
        # appending would leave stale pre-trim messages in agent.messages
        # and cause the same trim to fire on every subsequent request.
        with agent.messages_lock:
            trimmed = len(executor.messages) < original_length
            if trimmed:
                # Context was trimmed: the executor appended the new user
                # query *before* trimming, so the new messages (user +
                # assistant + tools) sit at the tail of the trimmed list.
                # We cannot simply slice at original_length (it exceeds the
                # list length).  Instead, count how many messages the
                # executor added on top of the post-trim baseline.
                #
                # Timeline inside executor.run_stream:
                #   1. messages had `original_length` items
                #   2. append user query  → original_length + 1
                #   3. _trim_messages()   → some smaller number (includes the
                #      user query because it belongs to the last turn)
                #   4. LLM replies / tool calls appended
                #
                # The user query message is always the first message of the
                # last turn (it cannot be trimmed away), so we locate it to
                # find where "new" messages begin.
                new_start = original_length  # fallback
                for idx in range(len(executor.messages) - 1, -1, -1):
                    msg = executor.messages[idx]
                    if msg.get("role") == "user":
                        content = msg.get("content", [])
                        is_user_query = False
                        if isinstance(content, list):
                            has_text = any(
                                isinstance(b, dict) and b.get("type") == "text"
                                for b in content
                            )
                            has_tool_result = any(
                                isinstance(b, dict) and b.get("type") == "tool_result"
                                for b in content
                            )
                            is_user_query = has_text and not has_tool_result
                        elif isinstance(content, str):
                            is_user_query = True
                        if is_user_query:
                            new_start = idx
                            break
                new_messages = list(executor.messages[new_start:])
            else:
                new_messages = list(executor.messages[original_length:])
            agent.messages = list(executor.messages)

        # Persist new messages to SQLite so they survive restarts and
        # can be queried via the HISTORY interface.
        if new_messages:
            self._persist_messages(
                session_id,
                list(new_messages),
                channel_type,
                workspace_root=agent.workspace_dir,
            )

        # Store executor reference for files_to_send access
        agent.stream_executor = executor

        # Execute post-process tools
        agent._execute_post_process_tools()

        # Record this user turn for the self-evolution idle trigger. This
        # streaming path bypasses agent_bridge.agent_reply, so the activity must
        # be noted here, otherwise idle scans never see any signal to evolve.
        self._note_evolution_turn(agent, context)

        logger.info(
            f"[ChatService] Agent run completed: agent={resolved_agent_id}, "
            f"session={session_id}"
        )



    @staticmethod
    def _build_context(
        query: str, session_id: str, channel_type: str, agent_id: str = "default"
    ):
        """Build a Context for tool resolution on the streaming chat path.

        receiver falls back to session_id; the scheduler's delivery keys on
        session_id as the receiver.
        """
        from bridge.context import Context, ContextType
        # Pass an explicit kwargs dict: Context's default kwargs is a shared
        # mutable default, so omitting it would leak fields across sessions.
        ctx = Context(ContextType.TEXT, query, kwargs={})
        ctx["session_id"] = session_id
        ctx["receiver"] = session_id
        ctx["isgroup"] = False
        ctx["channel_type"] = channel_type or ""
        ctx["agent_id"] = agent_id
        return ctx

    def _attach_context_aware_tools(self, agent, context):
        """Attach the current context to tools that need turn metadata."""
        try:
            if not (context and getattr(agent, "tools", None)):
                return
            for tool in agent.tools:
                if tool.name == "scheduler":
                    from agent.tools.scheduler.integration import attach_scheduler_to_tool
                    attach_scheduler_to_tool(tool, context)
                elif tool.name == "agent_delegate":
                    from agent.tools.agent_delegate.agent_delegate import attach_agent_delegate_to_tool
                    attach_agent_delegate_to_tool(tool, self.agent_bridge, context)
        except Exception as e:
            logger.warning(f"[ChatService] Failed to attach context to scheduler: {e}")

    @staticmethod
    def _mark_run_active(agent, active):
        """Toggle the self-evolution mid-run flag for this session's agent."""
        try:
            from agent.evolution.trigger import mark_run_active
            mark_run_active(agent, active)
        except Exception:
            pass

    @staticmethod
    def _note_evolution_turn(agent, context):
        """Record a user turn so the self-evolution idle trigger has signal."""
        try:
            from agent.evolution.trigger import note_user_turn
            ch = (context.get("channel_type") or "") if context else ""
            rcv = (context.get("receiver") or "") if context else ""
            is_group = bool(context.get("isgroup")) if context else False
            # Only single chats get a proactive push target; group push is noisy.
            note_user_turn(agent, channel_type=ch, receiver=(rcv if not is_group else ""))
        except Exception:
            pass

    @staticmethod
    def _persist_messages(
        session_id: str,
        new_messages: list,
        channel_type: str = "",
        workspace_root: str = None,
    ):
        try:
            from config import conf
            if not conf().get("conversation_persistence", True):
                return
        except Exception:
            pass
        try:
            from agent.memory import get_conversation_store
            get_conversation_store(workspace_root).append_messages(
                session_id, new_messages, channel_type=channel_type
            )
        except Exception as e:
            logger.warning(
                f"[ChatService] Failed to persist messages for session={session_id}: {e}"
            )


class _StreamState:
    """Mutable state shared between the event callback and the run method."""

    def __init__(self):
        self.segment_id: int = 0
        # None means we are not accumulating tool results right now.
        # A list means we are in the middle of a tool-execution phase.
        self.pending_tool_results: Optional[list] = None
        # Maps tool_call_id -> arguments captured from tool_execution_start,
        # so that tool_execution_end can attach the correct input args.
        self.pending_tool_arguments: dict = {}
        # Markdown links for files the send tool uploaded, held until the turn's
        # tool results have been flushed. Emitting one the moment the tool reports
        # it would place content between a tool's start and its result, which no
        # other event does and which leaves clients unable to pair the two.
        self.pending_file_links: list = []
